-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 26/06/2025 às 10:51
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `game_clock`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `conquistas`
--

CREATE TABLE `conquistas` (
  `id` int(11) NOT NULL,
  `jogo_id` int(11) NOT NULL,
  `nome_conquista` varchar(100) NOT NULL,
  `data_conquista` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `conquistas`
--

INSERT INTO `conquistas` (`id`, `jogo_id`, `nome_conquista`, `data_conquista`) VALUES
(3, 2, 't1', '2025-06-06 03:00:00'),
(4, 2, 't2', '2025-06-07 03:00:00'),
(5, 5, 'PAO', '2025-06-07 03:00:00'),
(6, 5, 'DE', '2025-06-13 03:00:00'),
(7, 5, 'QUEIJO', '2025-06-19 03:00:00'),
(8, 8, 'tt', '2025-06-20 03:00:00'),
(9, 9, '61', '2025-06-20 03:00:00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `emails_contato`
--

CREATE TABLE `emails_contato` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mensagem` text NOT NULL,
  `remetente_email` varchar(255) NOT NULL,
  `destinatario_email` varchar(255) NOT NULL,
  `data_envio` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `emails_contato`
--

INSERT INTO `emails_contato` (`id`, `nome`, `email`, `mensagem`, `remetente_email`, `destinatario_email`, `data_envio`) VALUES
(1, 'Teste01', 'teste@teste.com', 'BOA NOITE GALERAAAA', 'gameclockoficial@gmail.com', 'thiagogrunvaldt@gmail.com', '2025-06-26 02:35:35');

-- --------------------------------------------------------

--
-- Estrutura para tabela `jogos`
--

CREATE TABLE `jogos` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `genero` varchar(50) DEFAULT NULL,
  `data_lancamento` date DEFAULT NULL,
  `tempo_jogo` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `jogos`
--

INSERT INTO `jogos` (`id`, `usuario_id`, `titulo`, `genero`, `data_lancamento`, `tempo_jogo`) VALUES
(2, 7, 'Fallout', 'RPG', '2025-06-05', 10),
(5, 7, 'PAO DE QUEIJO', 'RPG', '2025-06-21', 0),
(6, 7, 'Minecraft', 'teste', '2025-06-14', 0),
(7, 7, 'COD 2', 'acao', '2025-06-28', 0),
(8, 6, 'Roblox', 'Infantil', '2025-06-13', 300),
(9, 13, 'Minecraft', 'RPG', '2025-06-13', 6),
(10, 13, 'GTA', 'Ação', '2025-06-13', 5),
(11, 13, 'GTA V', 'Ação', '2025-06-21', 61),
(12, 13, 'GTA VI', 'Ação', '2026-03-18', 101),
(13, 13, 'GTA: San Andreas', 'Ação', '2005-07-20', 39);

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome_usuario` varchar(50) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `descricao` text DEFAULT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  `id_personalizado` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome_usuario`, `senha`, `email`, `foto`, `descricao`, `criado_em`, `id_personalizado`) VALUES
(6, 'Teste', '$2y$10$K/yBvxDJEy5A1fUSZ8G4T.GKt5IjFTeG2LMnXx/4e56yRTohlCq6a', 'teste@teste.com', 'uploads/685303f6bc978.jpg', '123', '2025-06-18 18:22:46', 'Teste'),
(7, 'Pyrus Suryp', '$2y$10$B6KubV6ya4OrGtJay7SC4OB78wcKiiu8YDrVi0VWwAWZPIBCKYGDa', 'pyrusbr@gmail.com', 'uploads/685c41b8d0819.gif', 'Pyrus é o maior', '2025-06-18 18:26:12', 'Pyrus'),
(12, 'Pyrus2', '$2y$10$ANykQv8JnX6sg986JvlP.ORuMmq7AcaulRzDHh1BzPc4D7oRidNQ.', 'pyrusbr2@gmail.com', 'uploads/685c38dde18ff.gif', '123', '2025-06-25 17:58:53', '123'),
(13, 'Bilto', '$2y$10$A5m7AzpBfuetMQHyZb.ipeXMgnOToxqG5K3CIqVaU7Olv5PlfYOam', 'bagule@gmail.com', 'uploads/685d037f331de.png', 'Sou gordinho gostoso.', '2025-06-26 08:22:21', 'Bilto');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `conquistas`
--
ALTER TABLE `conquistas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jogo_id` (`jogo_id`);

--
-- Índices de tabela `emails_contato`
--
ALTER TABLE `emails_contato`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `jogos`
--
ALTER TABLE `jogos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nome_usuario` (`nome_usuario`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `id_personalizado` (`id_personalizado`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `conquistas`
--
ALTER TABLE `conquistas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `emails_contato`
--
ALTER TABLE `emails_contato`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `jogos`
--
ALTER TABLE `jogos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `conquistas`
--
ALTER TABLE `conquistas`
  ADD CONSTRAINT `conquistas_ibfk_1` FOREIGN KEY (`jogo_id`) REFERENCES `jogos` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `jogos`
--
ALTER TABLE `jogos`
  ADD CONSTRAINT `jogos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
