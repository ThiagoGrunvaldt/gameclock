<?php
require_once 'resources/header.php';
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GameClock</title>
</head>
<body>
    <div class="container mt-5">
      <h1>Index Aqui</h1>
    </div>
</body>
</html>

<?php
require_once 'resources/footer.php';
?>