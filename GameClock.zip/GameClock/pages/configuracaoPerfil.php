<?php
require_once '../resources/header.php';
require_once '../resources/usuario.php';
require_once '../resources/jogo.php';

$mensagem = "";

if (!isset($_SESSION['usuario_id'])) {
    header("Location: /GameClock/pages/login.php");
    exit;
}

$usuario = [
    'nome_usuario' => $_SESSION['usuario_nome'],
    'descricao' => $_SESSION['descricao'] ?? '',
    'id_personalizado' => $_SESSION['id_personalizado'],
    'foto' => $_SESSION['usuario_foto']
];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $mensagem = editarPerfil(
        $_SESSION['usuario_id'],
        $_POST['nome_usuario'],
        $_POST['descricao'],
        $_POST['id_personalizado'],
        $_FILES['foto']
    );

    if ($mensagem === "Perfil atualizado com sucesso!") {
        header("Location: /GameClock/pages/configuracaoPerfil.php");
        exit;
    }
}

$jogos = listarJogos($_SESSION['usuario_id']);

?>

<div class="container mt-5">
    <h1 class="mb-4">Configuração do Perfil</h1>
    <?php if (!empty($mensagem)): ?>
        <div class="alert alert-info"><?php echo htmlspecialchars($mensagem); ?></div>
    <?php endif; ?>
    <div class="card p-4 mb-5">
        <form method="POST" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-3 text-center">
                    <label for="foto" class="form-label">Foto</label>
                    <input type="file" class="form-control mb-3" id="foto" name="foto">
                    <?php if (!empty($usuario['foto'])): ?>
                        <img src="/GameClock/<?php echo htmlspecialchars($usuario['foto']); ?>" alt="Foto Atual" class="img-thumbnail" style="width: 150px; height: 150px;">
                    <?php endif; ?>
                </div>

                <div class="col-md-9">
                    <div class="mb-3">
                        <label for="id_personalizado" class="form-label">ID Personalizado</label>
                        <input type="text" class="form-control" id="id_personalizado" name="id_personalizado" value="<?php echo htmlspecialchars($usuario['id_personalizado']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="nome_usuario" class="form-label">Nome</label>
                        <input type="text" class="form-control" id="nome_usuario" name="nome_usuario" value="<?php echo htmlspecialchars($usuario['nome_usuario']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="descricao" class="form-label">Descrição</label>
                        <textarea class="form-control" id="descricao" name="descricao" rows="3" required><?php echo htmlspecialchars($usuario['descricao']); ?></textarea>
                    </div>
                </div>
            </div>
            <div class="text-end">
                <button type="submit" class="btn btn-primary">Salvar Alterações</button>
            </div>
        </form>
    </div>
</div>

<div class="container mt-5">
    <div class="text-end mb-4">
        <h1 class="text-center mb-4">Seus Jogos</h1>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addGameModal"><i class="bi bi-plus-circle"></i> Adicionar Jogo</button>
    </div>
    <div class="card p-4">
        <div class="row">
            <?php foreach ($jogos as $jogo): ?>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($jogo['titulo']); ?></h5>
                            <p class="card-text"><strong>Gênero:</strong> <?php echo htmlspecialchars($jogo['genero']); ?></p>
                            <p class="card-text"><strong>Data de Lançamento:</strong> <?php echo htmlspecialchars($jogo['data_lancamento']); ?></p>
                            <p class="card-text"><strong>Tempo de Jogo:</strong> <?php echo htmlspecialchars($jogo['tempo_jogo']); ?> horas</p>
                            <p class="card-text"><strong>Conquistas:</strong></p>
                            <ul>
                                <?php foreach ($jogo['conquistas'] as $conquista): ?>
                                    <li><?php echo htmlspecialchars($conquista['nome_conquista']); ?></li>
                                <?php endforeach; ?>
                            </ul>
                            <div class="d-flex justify-content-between">
                                <a href="/GameClock/pages/jogoDetalhes.php?jogo_id=<?php echo $jogo['id']; ?>" class="btn btn-primary btn-sm"><i class="bi bi-pencil"></i> Detalhes</a>
                                <button class="btn btn-danger btn-sm" onclick="excluirJogo(<?php echo $jogo['id']; ?>)"><i class="bi bi-trash"></i> Excluir</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<div class="modal fade" id="addGameModal" tabindex="-1" aria-labelledby="addGameModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="/GameClock/resources/jogo.php?acao=adicionar" id="formAdicionarJogo">
                <input type="hidden" name="usuario_id" value="<?php echo $_SESSION['usuario_id']; ?>">
                <div class="modal-header">
                    <h5 class="modal-title" id="addGameModalLabel">Adicionar Jogo</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="titulo" class="form-label">Título</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="titulo" name="titulo" required>
                            <button type="button" class="btn btn-secondary" id="validarNomeJogoBtn">
                                <i class="bi bi-gem"></i> Validar
                            </button>
                        </div>
                        <small id="validacaoFeedback" class="text-muted"></small>
                    </div>
                    <div class="mb-3">
                        <label for="genero" class="form-label">Gênero</label>
                        <input type="text" class="form-control" id="genero" name="genero" required>
                    </div>
                    <div class="mb-3">
                        <label for="data_lancamento" class="form-label">Data de Lançamento</label>
                        <input type="date" class="form-control" id="data_lancamento" name="data_lancamento" required>
                    </div>
                    <div class="mb-3">
                        <label for="tempo_jogo" class="form-label">Tempo de Jogo (em horas)</label>
                        <input type="number" class="form-control" id="tempo_jogo" name="tempo_jogo" min="0" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary" id="adicionarJogoBtn" disabled>Adicionar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.getElementById('validarNomeJogoBtn').addEventListener('click', async function () {
    const nomeJogo = document.getElementById('titulo').value.trim();
    const feedback = document.getElementById('validacaoFeedback');
    const adicionarBtn = document.getElementById('adicionarJogoBtn');

    if (!nomeJogo) {
        feedback.textContent = 'Por favor, insira o nome do jogo.';
        feedback.classList.add('text-danger');
        adicionarBtn.disabled = true;
        return;
    }

    feedback.textContent = 'Validando...';
    feedback.classList.remove('text-danger', 'text-success', 'text-warning');

    try {
        const response = await fetch('/GameClock/resources/validacaoJogosGemini.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ nomeJogo })
        });

        const data = await response.json();

        if (data.status === 'sucesso') {
            const resultado = data.resultado.trim().toLowerCase();

            if (resultado === 'válido') {
                feedback.textContent = 'Nome válido!';
                feedback.classList.add('text-success');
                adicionarBtn.disabled = false;
            } else if (resultado === 'possivelmente válido') {
                feedback.textContent = 'Nome possivelmente válido. Confirme se está correto.';
                feedback.classList.add('text-warning');
                adicionarBtn.disabled = false;
            } else {
                feedback.textContent = 'Nome inválido. Por favor, insira um nome válido.';
                feedback.classList.add('text-danger');
                adicionarBtn.disabled = true;
            }
        } else {
            feedback.textContent = 'Erro na validação. Tente novamente.';
            feedback.classList.add('text-danger');
            adicionarBtn.disabled = true;
        }
    } catch (error) {
        feedback.textContent = 'Erro ao conectar ao servidor. Tente novamente.';
        feedback.classList.add('text-danger');
        adicionarBtn.disabled = true;
    }
});

    function excluirJogo(jogoId) {
        if (confirm('Tem certeza que deseja excluir este jogo?')) {
            window.location.href = `/GameClock/resources/jogo.php?acao=excluir&jogo_id=${jogoId}`;
        }
    }
</script>

<?php require_once '../resources/footer.php'; ?>