<?php
require_once 'conexao.php';
require_once 'uploadFoto.php';

function cadastrarUsuario($nome_usuario, $email, $senha, $descricao, $id_personalizado, $foto) {
    $pdo = getConnection();

    if (!preg_match('/^[a-zA-Z0-9_-]+$/', $id_personalizado)) {
        return "O ID personalizado contém caracteres inválidos. Use apenas letras, números, hífen e sublinhado.";
    }

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE id_personalizado = :id_personalizado");
    $stmt->bindParam(':id_personalizado', $id_personalizado);
    $stmt->execute();
    if ($stmt->fetchColumn() > 0) {
        return "O ID personalizado já está em uso. Escolha outro.";
    }

    $stmtEmail = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE email = :email");
    $stmtEmail->bindParam(':email', $email);
    $stmtEmail->execute();
    if ($stmtEmail->fetchColumn() > 0) {
        return "O email já está em uso. Escolha outro.";
    }

    $foto_resultado = uploadFoto($foto);
    if (strpos($foto_resultado, "Erro") !== false || strpos($foto_resultado, "inválido") !== false) {
        return $foto_resultado;
    }

    $stmt = $pdo->prepare("INSERT INTO usuarios (nome_usuario, email, senha, descricao, id_personalizado, foto) 
                           VALUES (:nome_usuario, :email, :senha, :descricao, :id_personalizado, :foto)");
    $stmt->bindParam(':nome_usuario', $nome_usuario);
    $stmt->bindParam(':email', $email);
    $senhaHash = password_hash($senha, PASSWORD_DEFAULT);
    $stmt->bindParam(':senha', $senhaHash);
    $stmt->bindParam(':descricao', $descricao);
    $stmt->bindParam(':id_personalizado', $id_personalizado);
    $stmt->bindParam(':foto', $foto_resultado);
    $stmt->execute();

    return "Usuário cadastrado com sucesso!";
}

function loginUsuario($email, $senha) {
    $pdo = getConnection();

    $stmt = $pdo->prepare("SELECT id, id_personalizado, nome_usuario, senha, descricao, foto FROM usuarios WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario || !password_verify($senha, $usuario['senha'])) {
        return "Email ou senha inválidos.";
    }

    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $_SESSION['usuario_id'] = $usuario['id'];
    $_SESSION['id_personalizado'] = $usuario['id_personalizado'];
    $_SESSION['usuario_nome'] = $usuario['nome_usuario'];
    $_SESSION['descricao'] = $usuario['descricao'];
    $_SESSION['usuario_foto'] = $usuario['foto'];

    return "Login realizado com sucesso!";
}

function buscarUsuarioPorIdPersonalizado($id_personalizado) {
    $pdo = getConnection();
    $stmt = $pdo->prepare("SELECT id, nome_usuario, email, foto, descricao, criado_em FROM usuarios WHERE id_personalizado = :id_personalizado");
    $stmt->bindParam(':id_personalizado', $id_personalizado);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function editarPerfil($usuario_id, $nome_usuario, $descricao, $id_personalizado, $foto) {
    $pdo = getConnection();

    if (!preg_match('/^[a-zA-Z0-9_-]+$/', $id_personalizado)) {
        return "O ID personalizado contém caracteres inválidos. Use apenas letras, números, hífen e sublinhado.";
    }

    $stmtId = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE id_personalizado = :id_personalizado AND id != :usuario_id");
    $stmtId->bindParam(':id_personalizado', $id_personalizado);
    $stmtId->bindParam(':usuario_id', $usuario_id);
    $stmtId->execute();
    if ($stmtId->fetchColumn() > 0) {
        return "O ID personalizado já está em uso. Escolha outro.";
    }

    $foto_resultado = null;
    if ($foto && $foto['error'] === UPLOAD_ERR_OK) {
        $foto_resultado = uploadFoto($foto);
        if (strpos($foto_resultado, "Erro") !== false || strpos($foto_resultado, "inválido") !== false) {
            return $foto_resultado;
        }
    }

    $stmtUpdate = $pdo->prepare("UPDATE usuarios SET nome_usuario = :nome_usuario, descricao = :descricao, id_personalizado = :id_personalizado, foto = COALESCE(:foto, foto) WHERE id = :usuario_id");
    $stmtUpdate->bindParam(':nome_usuario', $nome_usuario);
    $stmtUpdate->bindParam(':descricao', $descricao);
    $stmtUpdate->bindParam(':id_personalizado', $id_personalizado);
    $stmtUpdate->bindParam(':foto', $foto_resultado);
    $stmtUpdate->bindParam(':usuario_id', $usuario_id);
    $stmtUpdate->execute();

    $stmtFetch = $pdo->prepare("SELECT id, id_personalizado, nome_usuario, descricao, foto FROM usuarios WHERE id = :usuario_id");
    $stmtFetch->bindParam(':usuario_id', $usuario_id);
    $stmtFetch->execute();
    $usuarioAtualizado = $stmtFetch->fetch(PDO::FETCH_ASSOC);

    $_SESSION['usuario_id'] = $usuarioAtualizado['id'];
    $_SESSION['id_personalizado'] = $usuarioAtualizado['id_personalizado'];
    $_SESSION['usuario_nome'] = $usuarioAtualizado['nome_usuario'];
    $_SESSION['descricao'] = $usuarioAtualizado['descricao'];
    $_SESSION['usuario_foto'] = $usuarioAtualizado['foto'];

    return "Perfil atualizado com sucesso!";
}