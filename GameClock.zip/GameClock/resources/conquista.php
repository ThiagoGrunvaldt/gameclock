<?php
require_once 'conexao.php';

if (isset($_GET['acao'])) {
    $acao = $_GET['acao'];

    switch ($acao) {
        case 'adicionar':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $jogo_id = htmlspecialchars($_POST['jogo_id']);
                $nome_conquista = htmlspecialchars($_POST['nome_conquista']);
                $data_conquista = htmlspecialchars($_POST['data_conquista']);
                adicionarConquista($jogo_id, $nome_conquista, $data_conquista);
                header("Location: /GameClock/pages/jogoDetalhes.php?jogo_id=$jogo_id");
                exit;
            }
            break;

        case 'editar':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $conquista_id = htmlspecialchars($_POST['conquista_id']);
                $nome_conquista = htmlspecialchars($_POST['nome_conquista']);
                $data_conquista = htmlspecialchars($_POST['data_conquista']);
                editarConquista($conquista_id, $nome_conquista, $data_conquista);
                $jogo_id = buscarJogoIdPorConquista($conquista_id);
                header("Location: /GameClock/pages/jogoDetalhes.php?jogo_id=$jogo_id");
                exit;
            }
            break;

        case 'excluir':
            if (isset($_GET['conquista_id'])) {
                $conquista_id = htmlspecialchars($_GET['conquista_id']);
                $jogo_id = buscarJogoIdPorConquista($conquista_id);
                excluirConquista($conquista_id);
                header("Location: /GameClock/pages/jogoDetalhes.php?jogo_id=$jogo_id");
                exit;
            }
            break;

        default:
            echo "Ação inválida.";
            exit;
    }
}

function listarConquistasPorJogo($jogo_id) {
    $pdo = getConnection();
    $stmt = $pdo->prepare("SELECT id, nome_conquista, data_conquista FROM conquistas WHERE jogo_id = :jogo_id");
    $stmt->bindParam(':jogo_id', $jogo_id);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function adicionarConquista($jogo_id, $nome_conquista, $data_conquista) {
    $pdo = getConnection();
    $stmt = $pdo->prepare("INSERT INTO conquistas (jogo_id, nome_conquista, data_conquista) VALUES (:jogo_id, :nome_conquista, :data_conquista)");
    $stmt->bindParam(':jogo_id', $jogo_id);
    $stmt->bindParam(':nome_conquista', $nome_conquista);
    $stmt->bindParam(':data_conquista', $data_conquista);
    $stmt->execute();
}

function editarConquista($conquista_id, $nome_conquista, $data_conquista) {
    $pdo = getConnection();
    $stmt = $pdo->prepare("UPDATE conquistas SET nome_conquista = :nome_conquista, data_conquista = :data_conquista WHERE id = :conquista_id");
    $stmt->bindParam(':nome_conquista', $nome_conquista);
    $stmt->bindParam(':data_conquista', $data_conquista);
    $stmt->bindParam(':conquista_id', $conquista_id);
    $stmt->execute();
}

function excluirConquista($conquista_id) {
    $pdo = getConnection();
    $stmt = $pdo->prepare("DELETE FROM conquistas WHERE id = :conquista_id");
    $stmt->bindParam(':conquista_id', $conquista_id);
    $stmt->execute();
}

function buscarJogoIdPorConquista($conquista_id) {
    $pdo = getConnection();
    $stmt = $pdo->prepare("SELECT jogo_id FROM conquistas WHERE id = :conquista_id");
    $stmt->bindParam(':conquista_id', $conquista_id);
    $stmt->execute();
    return $stmt->fetchColumn();
}